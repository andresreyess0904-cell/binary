"""
app_driver.py - Controlador de la aplicación RSIRAT
Encapsula:
  1. Apertira/cierre de app (pyautogui + .lnk)
  2. Login (campos, detección de errores contraseña)
  3. Navegación (Cobranza Coactiva, Exp. Cob. Individual)
  4. Entrada de expedientes (inicial, con Accesos)
  5. Accesos → Cambio de Expediente
  6. Trabar Embargo, Intervención, Depósito
  7. Ingreso de INTERVENTOR, PLAZO, MONTO
  8. Detecciones centralizadas de mensajes (MessageCatalog)
  9. Extracción de RC
  10. Cierre de diálogos

Retorna siempre Outcome explícito
"""

import time
import logging
import os
import re
from pathlib import Path
from typing import Optional, Tuple

import pyautogui
from pywinauto import Application, Desktop, findwindows

from workflow import Outcome


# ============================================================================
# CONSTANTES Y SELECTORES
# ============================================================================
RSIRAT_WINDOW_PATTERNS = [
    "RSIRAT",
    "COBRANZA"
]
RSIRAT_WAIT_TIMEOUT = 30
UI_WAIT_SMALL = 0.5
UI_WAIT_MEDIUM = 1.0
UI_WAIT_LARGE = 2.0
DETECT_TIMEOUT = 2.0
MSAA_BACKEND = "uia"





# ============================================================================
# APP DRIVER CLASS
# ============================================================================
class AppDriver:
    """Controlador de aplicación RSIRAT."""
    
    def __init__(self, logger: logging.Logger, shortcut_path: Path):
        self.logger = logger
        self.shortcut_path = shortcut_path
        self.app = None
        self.main_window = None
    
    # ========================================================================
    # APERTURA / CIERRE
    # ========================================================================
    
    def open_app(self) -> bool:
        """Abre RSIRAT usando el acceso directo."""
        try:
            self.logger.info(f"Abriendo {self.shortcut_path.name}...")
            os.startfile(str(self.shortcut_path))
            time.sleep(8)  # Esperar a que abra y cargue completamente
            self.logger.info("Aplicación abierta")
            return True
        except Exception as e:
            self.logger.error(f"Error abriendo aplicación: {e}")
            return False
    
    def close_app(self) -> bool:
        """Cierra RSIRAT con Alt+F4."""
        try:
            pyautogui.hotkey('alt', 'f4')
            time.sleep(2)
            self.logger.info("Aplicación cerrada")
            return True
        except Exception as e:
            self.logger.error(f"Error cerrando aplicación: {e}")
            return False
    
    # ========================================================================
    # LOGIN
    # ========================================================================
    
    def login(self, dependencia: str, password: str) -> Outcome:
        """
        Realiza login con reintentos dinámicos y tolerancia a delays.
        Espera hasta 30 segundos a que aparezca la ventana de login.
        Retorna OK_RC si login OK, FAIL_LOGIN_PASSWORD si hay error.
        """
        try:
            self.logger.info("Iniciando proceso de login...")
            
            # Esperar ventana de login con reintentos dinámicos
            self.logger.info("Esperando ventana de login (hasta 30 segundos)...")
            app = None
            dlg = None
            
            desktop = Desktop(backend=MSAA_BACKEND)
            start_time = time.time()
            timeout = 30
            
            while time.time() - start_time < timeout:
                try:
                    # Estrategia 1: Buscar por patrón de título
                    try:
                        dlg = desktop.window(title_re=".*(?:login|RSIRAT|SIRAT).*")
                        if dlg.exists(timeout=1):
                            self.logger.info(f"Ventana de login encontrada por patrón")
                            break
                    except Exception:
                        pass
                    
                    # Estrategia 2: Búsqueda manual en windows
                    if not dlg:
                        windows = desktop.windows()
                        for window in windows:
                            try:
                                title = str(window.element_info.name or "")
                                if "login" in title.lower() or "rsirat" in title.lower() or "sirat" in title.lower():
                                    dlg = window
                                    self.logger.info(f"Ventana de login encontrada: {title}")
                                    break
                            except Exception:
                                continue
                    
                    if dlg:
                        break
                except Exception as e:
                    self.logger.debug(f"Error buscando ventana de login: {e}")
                    pass
                
                time.sleep(0.5)
            
            if dlg is None:
                self.logger.error("No se pudo encontrar la ventana de login después de 30 segundos")
                return Outcome.FAIL_UI
            
            time.sleep(1)
            
            # Buscar campos de entrada con múltiples estrategias
            self.logger.info("Buscando campos de dependencia y contraseña...")
            dependencia_field = None
            password_field = None
            
            try:
                # Estrategia 1: Buscar por auto_id (si está disponible) - campos Edit
                try:
                    descendientes = list(dlg.descendants(control_type="Edit"))
                    if len(descendientes) >= 2:
                        dependencia_field = descendientes[0]
                        password_field = descendientes[1]
                        self.logger.info(f"Campos encontrados por tipo Edit: {len(descendientes)} campos")
                except Exception as e:
                    self.logger.debug(f"No se encontraron campos Edit: {e}")
            except Exception as e:
                self.logger.warning(f"Error en estrategia 1: {e}")
            
            # Estrategia 2: Búsqueda por nombre/label en descendientes
            if not dependencia_field or not password_field:
                try:
                    all_descendants = list(dlg.descendants())
                    self.logger.info(f"Total de descendientes: {len(all_descendants)}")
                    
                    for i, element in enumerate(all_descendants):
                        try:
                            name = str(element.element_info.name or "").lower()
                            ctrl_type = str(element.element_info.control_type or "")
                            
                            # Debug: mostrar algunos elementos
                            if i < 20 or "edit" in ctrl_type.lower():
                                self.logger.debug(f"Elemento {i}: '{name}' | Tipo: {ctrl_type}")
                            
                            if "dependencia" in name and "Edit" in ctrl_type and not dependencia_field:
                                dependencia_field = element
                                self.logger.info(f"Campo dependencia encontrado: {name}")
                            elif "contraseña" in name and "Edit" in ctrl_type and not password_field:
                                password_field = element
                                self.logger.info(f"Campo contraseña encontrado: {name}")
                            elif "password" in name and "Edit" in ctrl_type and not password_field:
                                password_field = element
                                self.logger.info(f"Campo password encontrado: {name}")
                        except Exception:
                            continue
                except Exception as e:
                    self.logger.warning(f"Error en estrategia 2: {e}")
            
            # Estrategia 3: Si aún no hay campos, usar los primeros 2 Edit encontrados
            if not dependencia_field or not password_field:
                try:
                    edit_fields = [e for e in dlg.descendants(control_type="Edit")]
                    if len(edit_fields) >= 2:
                        if not dependencia_field:
                            dependencia_field = edit_fields[0]
                            self.logger.info("Usando primer campo Edit como dependencia")
                        if not password_field:
                            password_field = edit_fields[1]
                            self.logger.info("Usando segundo campo Edit como contraseña")
                except Exception as e:
                    self.logger.warning(f"Error en estrategia 3: {e}")
            
            if dependencia_field is None or password_field is None:
                self.logger.error("No se pudieron localizar los campos de login")
                return Outcome.FAIL_UI
            
            # Preparar texto completo de dependencia para el login
            dep_code = str(dependencia).strip()
            dep_map = {
                "21": "0021 I.R. Lima - PRICO",
                "23": "0023 I.R. Lima - MEPECO",
            }
            login_dep = dep_map.get(dep_code, dependencia)

            # Ingresar dependencia (escribimos el nombre completo y luego TAB)
            self.logger.info(f"Ingresando dependencia para login: {login_dep}")
            try:
                dependencia_field.set_focus()
                time.sleep(0.2)
                pyautogui.write(login_dep, interval=0.05)
                time.sleep(0.2)
                pyautogui.press('tab')
                time.sleep(0.3)
            except Exception:
                # Fallback: si no es posible set_focus, intentar escribir directamente
                pyautogui.write(login_dep, interval=0.05)
                pyautogui.press('tab')
                time.sleep(0.3)

            # Ingresar contraseña (después de TAB debería estar en el campo)
            self.logger.info("Ingresando contraseña...")
            try:
                pyautogui.write(password, interval=0.05)
                time.sleep(0.2)
            except Exception:
                # Fallback: si falla, intentar usar el control password_field
                try:
                    password_field.set_focus()
                    time.sleep(0.2)
                    pyautogui.write(password, interval=0.05)
                    time.sleep(0.2)
                except Exception:
                    self.logger.warning("No se pudo ingresar la contraseña por los métodos habituales")
            
            # Hacer clic en Aceptar
            self.logger.info("Haciendo clic en Aceptar...")
            try:
                buttons = list(dlg.descendants(control_type="Button"))
                aceptar_btn = None
                for btn in buttons:
                    try:
                        btn_name = str(btn.element_info.name or "").lower()
                        if "aceptar" in btn_name or "ok" in btn_name:
                            aceptar_btn = btn
                            break
                    except Exception:
                        continue
                
                if aceptar_btn:
                    aceptar_btn.invoke()
                else:
                    self.logger.info("Botón no encontrado, presionando Enter...")
                    pyautogui.press('return')
            except Exception:
                self.logger.info("Presionando Enter para confirmar...")
                pyautogui.press('return')
            
            # Pequeña pausa para que aparezca posible error
            time.sleep(1)
            
            # Verificar si hay mensaje de error de contraseña
            pwd_err, pwd_msg = self.detect_password_error(timeout=2.0)
            if pwd_err:
                self.logger.error(f"Contraseña incorrecta. Mensaje: {pwd_msg}")
                # Presionar ENTER para cerrar el aviso de error
                time.sleep(0.5)
                pyautogui.press('return')
                time.sleep(0.5)
                # Presionar ALT+C para seleccionar 'Cancelar' y cerrar la aplicación (solo en etapa de login)
                self.logger.info("Presionando ALT+C para cancelar login y cerrar la app...")
                try:
                    pyautogui.hotkey('alt', 'c')
                except Exception:
                    # En caso de que hotkey falle, intentar enviar secuencia alternativa
                    pyautogui.keyDown('alt')
                    pyautogui.press('c')
                    pyautogui.keyUp('alt')
                time.sleep(1)
                return Outcome.FAIL_LOGIN_PASSWORD
            
            self.logger.info("Login completado exitosamente")
            return Outcome.OK_RC
        
        except Exception as e:
            self.logger.error(f"Error en login: {e}")
            return Outcome.FAIL_UI

    # ========================================================================
    # DETECTORES (copiados y adaptados de test2.py)
    # ========================================================================
    def detect_password_error(self, timeout=2):
        try:
            self.logger.info("Verificando si hay mensaje de error...")
            desktop = Desktop(backend=MSAA_BACKEND)
            end_time = time.time() + timeout
            while time.time() < end_time:
                try:
                    all_windows = desktop.windows()
                    for win in all_windows:
                        try:
                            all_descendants = list(win.descendants())
                            for desc in all_descendants:
                                try:
                                    control_type = None
                                    texto = ""
                                    try:
                                        if hasattr(desc, 'element_info'):
                                            control_type = desc.element_info.control_type
                                    except:
                                        pass
                                    try:
                                        texto = desc.window_text()
                                    except:
                                        pass
                                    if control_type == "Text" and texto and len(texto.strip()) > 0:
                                        texto_lower = texto.lower()
                                        palabras_clave = [
                                            "no puede ser accedido",
                                            "estimado usuario",
                                            "aplicativo",
                                            "credenciales",
                                            "error en las credenciales",
                                            "error numero"
                                        ]
                                        if any(palabra in texto_lower for palabra in palabras_clave):
                                            self.logger.error(f"Mensaje de error detectado: {texto}")
                                            return True, texto
                                except:
                                    pass
                        except:
                            pass
                except:
                    pass
                time.sleep(0.3)
            return False, ""
        except Exception as e:
            self.logger.error(f"Error en detect_password_error: {e}")
            return False, ""

    def detect_monto_aviso(self, timeout=2):
        try:
            self.logger.info("Verificando si hay mensaje de aviso del MONTO...")
            desktop = Desktop(backend=MSAA_BACKEND)
            end_time = time.time() + timeout
            while time.time() < end_time:
                try:
                    all_windows = desktop.windows()
                    for win in all_windows:
                        try:
                            all_descendants = list(win.descendants())
                            for desc in all_descendants:
                                try:
                                    control_type = None
                                    texto = ""
                                    try:
                                        if hasattr(desc, 'element_info'):
                                            control_type = desc.element_info.control_type
                                    except:
                                        pass
                                    try:
                                        texto = desc.window_text()
                                    except:
                                        pass
                                    if control_type == "Text" and texto and len(texto.strip()) > 0:
                                        texto_lower = texto.lower()
                                        palabras_clave = [
                                            "monto",
                                            "excede",
                                            "saldo",
                                            "expediente",
                                            "aviso",
                                            "error"
                                        ]
                                        if any(palabra in texto_lower for palabra in palabras_clave):
                                            self.logger.info(f"Mensaje de aviso detectado: {texto}")
                                            return True, texto
                                except:
                                    pass
                        except:
                            pass
                except:
                    pass
                time.sleep(0.3)
            return False, ""
        except Exception as e:
            self.logger.error(f"Error en detect_monto_aviso: {e}")
            return False, ""

    def detect_expediente_error(self, timeout=2):
        try:
            self.logger.info("Verificando si hay mensaje de error de expediente...")
            desktop = Desktop(backend=MSAA_BACKEND)
            end_time = time.time() + timeout
            while time.time() < end_time:
                try:
                    all_windows = desktop.windows()
                    for win in all_windows:
                        try:
                            all_descendants = list(win.descendants())
                            for desc in all_descendants:
                                try:
                                    control_type = None
                                    texto = ""
                                    try:
                                        if hasattr(desc, 'element_info'):
                                            control_type = desc.element_info.control_type
                                    except:
                                        pass
                                    try:
                                        texto = desc.window_text()
                                    except:
                                        pass
                                    if control_type == "Text" and texto and len(texto.strip()) > 0:
                                        texto_lower = texto.lower()
                                        if ("expediente" in texto_lower and "válido" in texto_lower) or \
                                           ("expediente" in texto_lower and "ingresado" in texto_lower):
                                            self.logger.warning(f"Error de expediente detectado: {texto}")
                                            return True, texto
                                except:
                                    pass
                        except:
                            pass
                except:
                    pass
                time.sleep(0.3)
            return False, ""
        except Exception as e:
            self.logger.error(f"Error en detect_expediente_error: {e}")
            return False, ""

    def detect_expediente_aviso(self, timeout=2):
        try:
            self.logger.info("Verificando si hay mensaje de aviso de expediente (IEI)...")
            desktop = Desktop(backend=MSAA_BACKEND)
            end_time = time.time() + timeout
            while time.time() < end_time:
                try:
                    all_windows = desktop.windows()
                    for win in all_windows:
                        try:
                            all_descendants = list(win.descendants())
                            for desc in all_descendants:
                                try:
                                    control_type = None
                                    texto = ""
                                    try:
                                        if hasattr(desc, 'element_info'):
                                            control_type = desc.element_info.control_type
                                    except:
                                        pass
                                    try:
                                        texto = desc.window_text()
                                    except:
                                        pass
                                    if control_type == "Text" and texto and len(texto.strip()) > 0:
                                        texto_lower = texto.lower()
                                        if ("expediente" in texto_lower and 
                                            "ruc" in texto_lower and 
                                            "embargo" in texto_lower and 
                                            "activo" in texto_lower):
                                            self.logger.warning(f"Aviso de embargos activos detectado")
                                            return True, texto
                                except:
                                    pass
                        except:
                            pass
                except:
                    pass
                time.sleep(0.3)
            return False, ""
        except Exception as e:
            self.logger.error(f"Error en detect_expediente_aviso: {e}")
            return False, ""

    def handle_dse_embargo_aviso(self, timeout=2) -> bool:
        """
        Detecta el aviso de embargos activos en DSE que aparece después del doble clic.
        Mensaje esperado: "El Expediente XXX correspondiente al RUC xxx tiene x Embargos activos..."
        Si se detecta, presiona Alt+S para continuar.
        
        Returns:
            True si se detectó y respondió al aviso (o no hay aviso)
            False si hay un error crítico
        """
        try:
            self.logger.info("Verificando si hay aviso de embargos activos (DSE)...")
            desktop = Desktop(backend=MSAA_BACKEND)
            end_time = time.time() + timeout
            
            while time.time() < end_time:
                try:
                    all_windows = desktop.windows()
                    for win in all_windows:
                        try:
                            all_descendants = list(win.descendants())
                            for desc in all_descendants:
                                try:
                                    control_type = None
                                    texto = ""
                                    try:
                                        if hasattr(desc, 'element_info'):
                                            control_type = desc.element_info.control_type
                                    except:
                                        pass
                                    try:
                                        texto = desc.window_text()
                                    except:
                                        pass
                                    
                                    if control_type == "Text" and texto and len(texto.strip()) > 0:
                                        texto_strip = texto.strip()
                                        # Búsqueda: comienza con "El Expediente" y contiene "embargo"
                                        if (texto_strip.startswith("El Expediente") and 
                                            "embargo" in texto_strip.lower() and
                                            "activo" in texto_strip.lower()):
                                            self.logger.info(f"✓ Aviso de embargos activos detectado")
                                            self.logger.info(f"Mensaje: {texto_strip[:100]}...")
                                            # Presionar Alt+S para continuar
                                            self.logger.info("Presionando Alt+S para continuar...")
                                            pyautogui.hotkey('alt', 's')
                                            time.sleep(1)
                                            self.logger.info("✓ Alt+S presionado")
                                            return True
                                except:
                                    pass
                        except:
                            pass
                except:
                    pass
                time.sleep(0.3)
            
            # No se detectó aviso (es normal si no hay embargos activos)
            self.logger.info("No se detectó aviso de embargos activos")
            return True
        
        except Exception as e:
            self.logger.error(f"Error en handle_dse_embargo_aviso: {e}")
            return False

    def extract_ruc_from_message(self, mensaje):
        try:
            self.logger.info("Extrayendo RUC del mensaje...")
            ruc_index = mensaje.upper().find("RUC")
            if ruc_index == -1:
                self.logger.warning("No se encontró 'RUC' en el mensaje")
                return ""
            texto_despues_ruc = mensaje[ruc_index + 3:].strip()
            self.logger.info(f"Texto después de 'RUC': '{texto_despues_ruc[:50]}'")
            ruc = ""
            for caracter in texto_despues_ruc:
                if caracter.isdigit():
                    ruc += caracter
                elif ruc:
                    break
            if ruc:
                self.logger.info(f" RUC extraído: {ruc}")
                return ruc
            else:
                self.logger.warning("No se encontraron dígitos después de 'RUC'")
                return ""
        except Exception as e:
            self.logger.error(f"Error extrayendo RUC: {e}")
            return ""

    def detect_resolucion_coactiva_aviso(self, timeout=2):
        try:
            self.logger.info("Verificando si hay mensaje de Resolución Coactiva...")
            desktop = Desktop(backend=MSAA_BACKEND)
            end_time = time.time() + timeout
            while time.time() < end_time:
                try:
                    all_windows = desktop.windows()
                    for win in all_windows:
                        try:
                            all_descendants = list(win.descendants())
                            for desc in all_descendants:
                                try:
                                    control_type = None
                                    texto = ""
                                    try:
                                        if hasattr(desc, 'element_info'):
                                            control_type = desc.element_info.control_type
                                    except:
                                        pass
                                    try:
                                        texto = desc.window_text()
                                    except:
                                        pass
                                    if control_type == "Text" and texto and len(texto.strip()) > 0:
                                        if "se grabó" in texto.lower() and "resolución coactiva" in texto.lower():
                                            self.logger.warning(f" MENSAJE DE RESOLUCIÓN COACTIVA DETECTADO: {texto[:100]}...")
                                            return True, texto
                                except:
                                    pass
                        except:
                            pass
                except:
                    pass
                time.sleep(0.3)
            return False, ""
        except Exception as e:
            self.logger.error(f"Error en detect_resolucion_coactiva_aviso: {e}")
            return False, ""

    def extract_resolucion_coactiva_number(self, mensaje):
        try:
            self.logger.info("Extrayendo número de Resolución Coactiva del mensaje...")
            numero_index = mensaje.lower().find("número")
            if numero_index == -1:
                self.logger.warning("No se encontró 'palabra 'número' en el mensaje")
                return ""
            texto_despues_numero = mensaje[numero_index + 6:].strip()
            self.logger.info(f"Texto después de 'número': '{texto_despues_numero[:50]}'")
            rc_number = ""
            for caracter in texto_despues_numero:
                if caracter.isdigit():
                    rc_number += caracter
                elif rc_number:
                    break
            if rc_number:
                self.logger.info(f" Número de RC extraído: {rc_number}")
                return rc_number
            else:
                self.logger.warning("No se encontraron dígitos después de 'número'")
                return ""
        except Exception as e:
            self.logger.error(f"Error extrayendo número de RC: {e}")
            return ""

    def detect_desea_continuar_aviso(self, timeout=2):
        try:
            self.logger.info("Verificando si hay mensaje '¿ Desea Continuar ?'...")
            desktop = Desktop(backend=MSAA_BACKEND)
            end_time = time.time() + timeout
            while time.time() < end_time:
                try:
                    dlgs = desktop.windows()
                    for dlg in dlgs:
                        try:
                            descendants = dlg.descendants()
                            for desc in descendants:
                                try:
                                    texto = desc.window_text()
                                    texto_lower = texto.lower()
                                    if "desea" in texto_lower and "continuar" in texto_lower:
                                        self.logger.warning(f"Aviso '¿ Desea Continuar ?' detectado")
                                        return True, texto
                                except Exception:
                                    pass
                        except Exception:
                            pass
                except Exception:
                    pass
                time.sleep(0.1)
            return False, ""
        except Exception as e:
            self.logger.error(f"Error en detect_desea_continuar_aviso: {e}")
            return False, ""

    def detect_interventor_error(self, timeout=2):
        try:
            self.logger.info("Verificando si hay mensaje 'Código de Interventor incorrecto'...")
            desktop = Desktop(backend=MSAA_BACKEND)
            end_time = time.time() + timeout
            while time.time() < end_time:
                try:
                    dlgs = desktop.windows()
                    for dlg in dlgs:
                        try:
                            descendants = dlg.descendants()
                            for desc in descendants:
                                try:
                                    texto = desc.window_text()
                                    texto_lower = texto.lower()
                                    if ("codigo" in texto_lower and 
                                        "interventor" in texto_lower and 
                                        "incorrecto" in texto_lower):
                                        self.logger.warning(f"Error de INTERVENTOR detectado: '{texto}'")
                                        return True, texto
                                except Exception:
                                    pass
                        except Exception:
                            pass
                except Exception:
                    pass
                time.sleep(0.1)
            return False, ""
        except Exception as e:
            self.logger.error(f"Error en detect_interventor_error: {e}")
            return False, ""

    def detect_rc_message(self, timeout=3):
        """
        Detecta el mensaje "Se grabó la Resolución Coactiva con el número XXX"
        y extrae el número RC preservando los 0s iniciales.
        
        Retorna: (True, "numero_rc") si se detecta, (False, "") si no
        
        IMPORTANTE: El número se retorna como STRING para preservar 0s iniciales
        Ejemplo: "00123456" no "123456"
        
        El mensaje puede variar ligeramente pero siempre contiene:
        - "grabó" o "grabar"
        - "resolución" o "coactiva"
        - "número" seguido de dígitos
        """
        try:
            self.logger.info("Buscando mensaje de RC: 'Se grabó la Resolución Coactiva con el número'...")
            desktop = Desktop(backend=MSAA_BACKEND)
            end_time = time.time() + timeout
            
            import re
            
            while time.time() < end_time:
                try:
                    for win in desktop.windows():
                        try:
                            for desc in win.descendants():
                                try:
                                    texto = str(desc.window_text() or "").strip()
                                    texto_lower = texto.lower()
                                    
                                    # Búsqueda flexible: debe contener palabras clave
                                    if any(word in texto_lower for word in ["grabó", "grabar"]) and \
                                       any(word in texto_lower for word in ["resolución", "coactiva"]) and \
                                       "número" in texto_lower:
                                        
                                        self.logger.info(f"✓ Mensaje de RC detectado: {texto}")
                                        
                                        # Extraer números después de "número"
                                        match = re.search(r'número\s+(\d+)', texto, re.IGNORECASE)
                                        if match:
                                            rc_number = match.group(1)
                                            self.logger.info(f"✓ RC extraída como STRING: {rc_number}")
                                            return True, rc_number
                                        else:
                                            # Fallback: buscar cualquier secuencia de dígitos después de "número"
                                            idx = texto_lower.find("número")
                                            if idx >= 0:
                                                rest = texto[idx + 6:].strip()
                                                digits = ""
                                                for char in rest:
                                                    if char.isdigit():
                                                        digits += char
                                                    elif digits:  # Ya tenemos dígitos y encontramos no-dígito
                                                        break
                                                if digits:
                                                    self.logger.info(f"✓ RC extraída (fallback): {digits}")
                                                    return True, digits
                                        
                                except Exception:
                                    pass
                        except Exception:
                            pass
                except Exception:
                    pass
                
                time.sleep(0.3)
            
            self.logger.warning(f"No se detectó mensaje de RC después de {timeout} segundos")
            return False, ""
        
        except Exception as e:
            self.logger.error(f"Error en detect_rc_message: {e}")
            return False, ""
    
    # ========================================================================
    # NAVEGACIÓN BÁSICA
    # ========================================================================
    
    def navigate_to_module(self) -> bool:
        """
        Navega a Cobranza Coactiva con reintentos (hasta 360 segundos).
        UNA VEZ que se hace clic en "Cobranza Coactiva", retorna True.
        Los 4 clics en "Exp. Cob. Coactiva - Individual" se hacen en click_exp_individual().
        """
        try:
            self.logger.info("Buscando 'Cobranza Coactiva' (búsqueda robusta con reintentos)...")
            
            timeout_segundos = 360
            tiempo_inicio = time.time()
            intento = 0
            
            while time.time() - tiempo_inicio < timeout_segundos:
                intento += 1
                tiempo_transcurrido = int(time.time() - tiempo_inicio)
                self.logger.info(f"Intento {intento} (tiempo: {tiempo_transcurrido}/{timeout_segundos}s)")
                
                try:
                    desktop = Desktop(backend=MSAA_BACKEND)
                    menu_windows = []
                    
                    # Buscar ventana de menú
                    try:
                        win = desktop.window(title_re=".*Menú.*")
                        if win.exists(timeout=1):
                            menu_windows.append(win)
                            self.logger.info("Ventana Menú encontrada")
                    except Exception:
                        pass
                    
                    # Fallback: buscar ventana SIRAT
                    if not menu_windows:
                        try:
                            win = desktop.window(title_re=".*SIRAT.*")
                            if win.exists(timeout=1):
                                menu_windows.append(win)
                                self.logger.info("Ventana SIRAT encontrada")
                        except Exception:
                            pass
                    
                    if not menu_windows:
                        self.logger.info(f"Intento {intento}: ventanas no encontradas, reintentando...")
                        time.sleep(2)
                        continue
                    
                    app_window = menu_windows[0]
                    encontrado = False
                    
                    # Método 1: buscar por título exacto
                    try:
                        cobranza_control = app_window.child_window(title="Cobranza Coactiva")
                        if cobranza_control.exists(timeout=1):
                            self.logger.info("Elemento encontrado por título, haciendo clic...")
                            rect = cobranza_control.rectangle()
                            center_x = (rect.left + rect.right) // 2
                            center_y = (rect.top + rect.bottom) // 2
                            pyautogui.click(center_x, center_y)
                            time.sleep(1)
                            encontrado = True
                    except Exception:
                        pass
                    
                    # Método 2: búsqueda parcial en descendientes
                    if not encontrado:
                        try:
                            descendants = app_window.descendants()
                            for descendant in descendants:
                                try:
                                    texto = descendant.window_text()
                                    if "Cobranza" in texto and "Coactiva" in texto:
                                        self.logger.info("Elemento encontrado en descendientes, haciendo clic...")
                                        rect = descendant.rectangle()
                                        if rect.left >= 0 or rect.top >= 0:
                                            center_x = (rect.left + rect.right) // 2
                                            center_y = (rect.top + rect.bottom) // 2
                                            pyautogui.click(center_x, center_y)
                                            time.sleep(1)
                                            encontrado = True
                                            break
                                except Exception:
                                    pass
                        except Exception:
                            pass
                    
                    if encontrado:
                        self.logger.info("Clic en 'Cobranza Coactiva' completado")
                        time.sleep(1)
                        # Ahora intentar seleccionar 'Exp. Cob. Coactiva - Individual'
                        ok = self.click_exp_individual()
                        if not ok:
                            self.logger.error("No se pudo seleccionar 'Exp. Cob. Coactiva - Individual' después de clicar Cobranza Coactiva")
                            return False
                        return True
                    
                    self.logger.info(f"Intento {intento}: elemento no encontrado, reintentando...")
                    
                except Exception as e:
                    self.logger.warning(f"Error en intento {intento}: {e}")
                
                time.sleep(2)
            
            # Timeout alcanzado
            self.logger.error(f"Timeout alcanzado ({timeout_segundos}s) buscando 'Cobranza Coactiva'")
            return False
            
        except Exception as e:
            self.logger.error(f"Error navegando al módulo: {e}")
            return False
    
    def click_exp_individual(self):
        """
        Hace 4 clics en 'Exp. Cob. Coactiva - Individual'.
        Se llama DESPUÉS de navigate_to_module().
        Maneja espacios al final del nombre correctamente.
        """
        try:
            self.logger.info("Haciendo 4 clics en 'Exp. Cob. Coactiva - Individual'...")
            desktop = Desktop(backend=MSAA_BACKEND)
            exp_individual_clicks = 0

            # Buscar el control exacto primero (strip para espacios finales)
            target_element = None
            for win in desktop.windows():
                try:
                    for element in win.descendants():
                        try:
                            texto = element.window_text() or ""
                            if texto.strip() == "Exp. Cob. Coactiva - Individual":
                                target_element = element
                                break
                        except Exception:
                            continue
                    if target_element:
                        break
                except Exception:
                    continue

            # Fallback a búsqueda flexible si no se encontró exacto
            if not target_element:
                for win in desktop.windows():
                    try:
                        for element in win.descendants():
                            try:
                                texto = element.window_text() or ""
                                texto_strip = texto.strip()
                                if "Exp" in texto_strip and "Individual" in texto_strip and "Cob" in texto_strip:
                                    target_element = element
                                    break
                            except Exception:
                                continue
                        if target_element:
                            break
                    except Exception:
                        continue

            if not target_element:
                self.logger.warning("No se encontró el control 'Exp. Cob. Coactiva - Individual' en ninguna ventana")
                return False

            # Obtener coordenadas del elemento y hacer 4 clics en el mismo punto
            try:
                rect = target_element.rectangle()
                center_x = (rect.left + rect.right) // 2
                center_y = (rect.top + rect.bottom) // 2
            except Exception:
                # Fallback: usar .legacy_properties() o window_text position not available
                try:
                    bbox = target_element.element_info.rectangle
                    center_x = (bbox.left + bbox.right) // 2
                    center_y = (bbox.top + bbox.bottom) // 2
                except Exception:
                    self.logger.warning("No se pudieron obtener coordenadas del control 'Exp. Individual'")
                    return False

            control_type = getattr(target_element.element_info, 'control_type', 'unknown')
            self.logger.info(f"Encontrado control: { (target_element.window_text() or '').strip() }")
            self.logger.info(f"Control type: {control_type}")

            for i in range(4):
                pyautogui.click(center_x, center_y)
                exp_individual_clicks += 1
                self.logger.info(f"Clic {i+1}/4 en coordenadas: ({center_x}, {center_y})")
                time.sleep(0.3)

            if exp_individual_clicks >= 4:
                self.logger.info("✓ Se completaron 4 clics en 'Exp. Cob. Coactiva - Individual'")
                return True
            else:
                self.logger.warning(f"⚠ Solo se hicieron {exp_individual_clicks} clics en 'Exp. Individual' (esperados 4)")
                return False

        except Exception as e:
            self.logger.error(f"Error en click_exp_individual: {e}")
            return False
    
    # ========================================================================
    # ENTRADA DE EXPEDIENTES
    # ========================================================================
    
    def enter_expediente_initial(self, expediente: str) -> Tuple[Outcome, Optional[str]]:
        """
        Ingresa el primer expediente (sin usar Accesos).
        Preserva ceros iniciales (ej: 029 no se convierte a 29).
        Retorna (Outcome, rc_si_aplica)
        """
        try:
            self.logger.info(f"Ingresando expediente inicial: {expediente}")
            
            # Buscar campo PBEDIT flexible (soporta variantes PBEDIT124, PBEDIT125, etc.)
            numero_field = self._find_pbedit_field()
            
            if not numero_field:
                self.logger.error("No se encontró campo PBEDIT")
                return (Outcome.FAIL_UI, None)
            
            # Limpiar campo antes de digitar
            numero_field.set_focus()
            time.sleep(0.3)
            for _ in range(15):
                pyautogui.hotkey('ctrl', 'backspace')
                time.sleep(0.05)
            time.sleep(0.3)
            
            # Digitar expediente carácter por carácter para preservar ceros iniciales
            self.logger.info(f"Escribiendo expediente: {expediente}")
            self._type_string_preserving_zeros(expediente)
            time.sleep(0.5)
            
            # Presionar ENTER
            pyautogui.press('return')
            time.sleep(1.5)
            
            # Detectar error de expediente (esperar 2.0s para estar seguro)
            exp_err, exp_msg = self.detect_expediente_error(timeout=2.0)
            if exp_err:
                self.logger.warning(f"Expediente inválido: {exp_msg}")
                pyautogui.press('escape')
                time.sleep(0.5)
                return (Outcome.SKIP_EXP_INVALIDO, None)
            
            self.logger.info(f"Expediente ingresado: {expediente}")
            return (Outcome.OK_RC, None)  # OK_RC indica que pasó validación, no que hay RC
        
        except Exception as e:
            self.logger.error(f"Error ingresando expediente inicial: {e}")
            return (Outcome.FAIL_UI, None)
    
    def enter_expediente_change(self, expediente: str) -> Tuple[Outcome, Optional[str]]:
        """
        Ingresa expediente usando Accesos → Cambio de Expediente.
        Preserva ceros iniciales (ej: 029 no se convierte a 29).
        Retorna (Outcome, rc_si_aplica)
        """
        try:
            self.logger.info(f"Ingresando expediente (con Cambio): {expediente}")
            
            # Buscar campo PBEDIT flexible (soporta variantes PBEDIT124, PBEDIT125, etc.)
            numero_field = self._find_pbedit_field()
            
            if not numero_field:
                self.logger.error("No se encontró campo PBEDIT")
                return (Outcome.FAIL_UI, None)
            
            # Limpiar campo antes de digitar
            numero_field.set_focus()
            time.sleep(0.3)
            for _ in range(15):
                pyautogui.hotkey('ctrl', 'backspace')
                time.sleep(0.05)
            time.sleep(0.3)
            
            # Digitar expediente carácter por carácter para preservar ceros iniciales
            self.logger.info(f"Escribiendo expediente: {expediente}")
            self._type_string_preserving_zeros(expediente)
            time.sleep(0.5)
            
            # Presionar ENTER
            pyautogui.press('return')
            time.sleep(1.5)
            
            # Detectar error (esperar 2.0s para estar seguro)
            exp_err, exp_msg = self.detect_expediente_error(timeout=2.0)
            if exp_err:
                self.logger.warning(f"Expediente inválido: {exp_msg}")
                pyautogui.press('escape')
                time.sleep(0.5)
                return (Outcome.SKIP_EXP_INVALIDO, None)
            
            self.logger.info(f"Expediente ingresado: {expediente}")
            return (Outcome.OK_RC, None)
        
        except Exception as e:
            self.logger.error(f"Error ingresando expediente (cambio): {e}")
            return (Outcome.FAIL_UI, None)
    
    # ========================================================================
    # NAVEGACIÓN ACCESOS
    # ========================================================================
    
    def iter_all_descendants(self):
        """
        Generador que itera de forma robusta por todos los elementos (descendientes)
        de las ventanas detectadas por `Desktop`. Evita llamar `desktop.descendants()`
        directamente porque puede no existir en algunos wrappers.
        """
        try:
            desktop = Desktop(backend=MSAA_BACKEND)
            for win in desktop.windows():
                try:
                    for desc in win.descendants():
                        yield desc
                except Exception:
                    continue
        except Exception:
            return
    
    def _find_pbedit_field(self) -> Optional[object]:
        """
        Busca campo PBEDIT de forma flexible.
        Prioridad: PBEDIT125 (para expedientes) → PBEDIT124 → Otros PBEDIT* → Fallback Edit
        
        PBEDIT125 es el campo estándar para expedientes en "Cambio de Expediente".
        
        Soporta variantes: PBEDIT124, PBEDIT125, PBEDIT126, etc.
        Fallback: busca cualquier campo editable con rol 'texto modificable'.
        Retorna el elemento o None si no se encuentra.
        """
        desktop = Desktop(backend=MSAA_BACKEND)
        
        # Estrategia 1: Buscar PBEDIT125 específicamente (expedientes)
        self.logger.info("Buscando PBEDIT125 (campo estándar para expedientes)...")
        for win in desktop.windows():
            try:
                for element in win.descendants():
                    try:
                        class_name = str(element.element_info.class_name or "").strip()
                        if class_name == "PBEDIT125":
                            self.logger.info(f"✓ {class_name} encontrado (estándar para expedientes)")
                            return element
                    except Exception:
                        continue
            except Exception:
                continue
        
        # Estrategia 2: Buscar otros PBEDIT* (PBEDIT124, etc.)
        self.logger.info("PBEDIT125 no encontrado, buscando otro PBEDIT*...")
        for win in desktop.windows():
            try:
                for element in win.descendants():
                    try:
                        class_name = str(element.element_info.class_name or "").strip()
                        # Buscar cualquier PBEDIT seguido de números
                        if class_name.startswith("PBEDIT"):
                            self.logger.info(f"Campo {class_name} encontrado (fallback)")
                            return element
                    except Exception:
                        continue
            except Exception:
                continue
        
        # Estrategia 3: Fallback - buscar por rol "texto modificable" o similar
        self.logger.info("PBEDIT* no encontrado, usando fallback (campo Edit)...")
        for win in desktop.windows():
            try:
                for element in win.descendants():
                    try:
                        control_type = str(element.element_info.control_type or "")
                        # En español puede ser "texto modificable", en inglés "Edit"
                        if "Edit" in control_type or "text" in control_type.lower():
                            self.logger.info(f"Campo editable encontrado por tipo: {control_type}")
                            return element
                    except Exception:
                        continue
            except Exception:
                continue
        
        return None
    
    def _type_string_preserving_zeros(self, text: str) -> None:
        """
        Escribe un string carácter por carácter para preservar ceros iniciales.
        Evita que pyautogui.write() interprete '029' como número 29.
        """
        text_str = str(text)  # Asegurar que es string
        for char in text_str:
            pyautogui.typewrite(char, interval=0.05)  # typewrite es más seguro para caracteres
        time.sleep(0.2)

    def clear_expediente_field(self) -> None:
        """Busca el campo PBEDIT y lo limpia usando Ctrl+Backspace 15 veces."""
        try:
            field = self._find_pbedit_field()
            if not field:
                return
            field.set_focus()
            time.sleep(0.2)
            for _ in range(15):
                pyautogui.hotkey('ctrl', 'backspace')
                time.sleep(0.03)
            time.sleep(0.1)
        except Exception:
            return

    def get_assigned_interventor(self, timeout=1.0) -> str:
        """
        Busca específicamente el control con class_name="pbdwst125" (o variante pbdwst*)
        y extrae el nombre del ejecutor/interventor asignado.
        Retorna string vacío si no encuentra.
        """
        try:
            self.logger.info("Buscando nombre del ejecutor en control pbdwst...")
            end_time = time.time() + timeout
            
            while time.time() < end_time:
                desktop = Desktop(backend=MSAA_BACKEND)
                
                # Buscar control con class_name que empiece con "pbdwst"
                for element in self.iter_all_descendants():
                    try:
                        class_name = str(element.element_info.class_name or "").strip()
                        
                        # Buscar pbdwst125, pbdwst124, pbdwst126, etc.
                        if class_name.upper().startswith("PBDWST"):
                            name = str(element.element_info.name or "").strip()
                            
                            # El name del control es el nombre del ejecutor
                            if name and len(name.split()) >= 2 and not any(ch.isdigit() for ch in name):
                                self.logger.info(f"Ejecutor encontrado en {class_name}: {name}")
                                return name
                    except Exception:
                        continue
                
                time.sleep(0.1)
            
            self.logger.debug("No se encontró control pbdwst con nombre de ejecutor")
            return ""
        
        except Exception as e:
            self.logger.debug(f"Error en get_assigned_interventor: {e}")
            return ""

    def go_to_accesos_change_expediente(self) -> bool:
        """Va a Accesos → Cambio de Expediente."""
        try:
            self.logger.info("Navegando a Accesos → Cambio de Expediente...")
            
            desktop = Desktop(backend=MSAA_BACKEND)
            
            # Click en Accesos
            for element in self.iter_all_descendants():
                try:
                    name = str(element.element_info.name or "").strip().lower()
                    if name == "accesos":
                        element.click()
                        self.logger.info("  Click en Accesos")
                        time.sleep(0.5)
                        break
                except Exception:
                    continue
            
            # Doble click en Cambio de Expediente
            for element in self.iter_all_descendants():
                try:
                    name = str(element.element_info.name or "").lower()
                    if "cambio" in name and "expediente" in name:
                        element.double_click()
                        self.logger.info("  Doble click en Cambio de Expediente")
                        time.sleep(0.5)
                        return True
                except Exception:
                    continue
            
            self.logger.warning("No se encontró Cambio de Expediente")
            return False
        
        except Exception as e:
            self.logger.error(f"Error navegando a Accesos: {e}")
            return False
    
    # ========================================================================
    # NAVEGACIÓN EMBARGO
    # ========================================================================
    
    def go_to_trabar_embargo(self) -> bool:
        """
        Navega a Proceso de Embargo → Trabar Embargo usando patrón robusto.
        Busca exactamente los textos, usa strip() para eliminar espacios ocultos,
        y utiliza coordenadas del rectángulo del elemento para clic preciso.
        """
        try:
            self.logger.info("Navegando a 'Proceso de Embargo'...")
            
            desktop = Desktop(backend=MSAA_BACKEND)
            
            # ---- PASO 1: Buscar y hacer clic en "Proceso de Embargo" ----
            app = None
            try:
                app = desktop.window(title_re=".*SIRAT.*")
                if not app.exists(timeout=2):
                    app = None
            except Exception:
                app = None
            
            if not app:
                try:
                    app = desktop.active()
                except Exception:
                    app = None
            
            if not app:
                self.logger.error("No se encontró ventana SIRAT")
                return False
            
            # Buscar "Proceso de Embargo" en descendientes
            try:
                descendants = app.descendants()
                self.logger.info(f"Total de descendientes: {len(descendants)}")
                
                encontrado_proceso_embargo = False
                for i, descendant in enumerate(descendants):
                    try:
                        desc_text = descendant.window_text().strip()
                        
                        # Búsqueda exacta: "Proceso de Embargo"
                        if desc_text == "Proceso de Embargo":
                            self.logger.info(f"✓ 'Proceso de Embargo' encontrado en índice {i}")
                            rect = descendant.rectangle()
                            
                            if rect.width() > 0 and rect.height() > 0:
                                click_x = (rect.left + rect.right) // 2
                                click_y = (rect.top + rect.bottom) // 2
                                self.logger.info(f"Coordenadas: ({click_x}, {click_y})")
                                pyautogui.click(click_x, click_y)
                                self.logger.info("✓ Clic en Proceso de Embargo completado")
                                time.sleep(1)
                                encontrado_proceso_embargo = True
                                break
                    except Exception:
                        pass
                
                if not encontrado_proceso_embargo:
                    self.logger.warning("No se encontró exacto 'Proceso de Embargo'")
                    return False
                
            except Exception as e:
                self.logger.error(f"Error buscando Proceso de Embargo: {e}")
                return False
            
            # ---- PASO 2: Buscar y hacer clic en "Trabar Embargo" ----
            self.logger.info("Navegando a 'Trabar Embargo'...")
            
            try:
                # Volver a obtener descendientes (podría cambiar después de expandir)
                descendants = app.descendants()
                self.logger.info(f"Total de descendientes (después de Proceso): {len(descendants)}")
                
                for i, descendant in enumerate(descendants):
                    try:
                        desc_text = descendant.window_text().strip()
                        
                        # Búsqueda exacta: "Trabar Embargo"
                        if desc_text == "Trabar Embargo":
                            self.logger.info(f"✓ 'Trabar Embargo' encontrado en índice {i}")
                            rect = descendant.rectangle()
                            
                            if rect.width() > 0 and rect.height() > 0:
                                click_x = (rect.left + rect.right) // 2
                                click_y = (rect.top + rect.bottom) // 2
                                self.logger.info(f"Coordenadas: ({click_x}, {click_y})")
                                pyautogui.click(click_x, click_y)
                                self.logger.info("✓ Clic en Trabar Embargo completado")
                                time.sleep(1)
                                return True
                            else:
                                # Intentar invoke si coordenadas inválidas
                                self.logger.info("Coordenadas inválidas, intentando invoke...")
                                try:
                                    descendant.invoke()
                                    time.sleep(1)
                                    return True
                                except Exception:
                                    pyautogui.press('return')
                                    time.sleep(1)
                                    return True
                    except Exception:
                        pass
                
                self.logger.warning("No se encontró 'Trabar Embargo'")
                return False
            
            except Exception as e:
                self.logger.error(f"Error buscando Trabar Embargo: {e}")
                return False
        
        except Exception as e:
            self.logger.error(f"Error en go_to_trabar_embargo: {e}")
            return False
    
    # ========================================================================
    # IEI (INTERVENCIÓN)
    # ========================================================================
    
    def click_trabar_intervencion(self) -> bool:
        """Hace doble clic en 'Trabar Intervención en Información' usando patrón robusto."""
        try:
            self.logger.info("Buscando 'Trabar Intervención en Información'...")
            
            desktop = Desktop(backend=MSAA_BACKEND)
            
            # Buscar ventana SIRAT
            app = None
            try:
                app = desktop.window(title_re=".*SIRAT.*")
                if not app.exists(timeout=2):
                    app = None
            except Exception:
                app = None
            
            if not app:
                try:
                    app = desktop.active()
                except Exception:
                    app = None
            
            if not app:
                self.logger.error("No se encontró ventana SIRAT")
                return False
            
            self.logger.info("Ventana encontrada, iterando descendientes...")
            
            try:
                descendants = app.descendants()
                self.logger.info(f"Total de descendientes: {len(descendants)}")
                
                # Iterar todos los descendientes y buscar "Trabar Intervención en Información"
                for i, descendant in enumerate(descendants):
                    try:
                        desc_text = descendant.window_text().strip()  # ← IMPORTANTE: strip()
                        
                        # Búsqueda exacta con strip()
                        if desc_text == "Trabar Intervención en Información":
                            self.logger.info(f"✓ 'Trabar Intervención en Información' encontrado en índice {i}")
                            rect = descendant.rectangle()
                            
                            if rect.width() > 0 and rect.height() > 0:
                                click_x = (rect.left + rect.right) // 2
                                click_y = (rect.top + rect.bottom) // 2
                                self.logger.info(f"Coordenadas válidas: ({click_x}, {click_y})")
                                self.logger.info(f"Haciendo DOBLE CLIC en: ({click_x}, {click_y})")
                                pyautogui.doubleClick(click_x, click_y)
                                time.sleep(1.5)
                                self.logger.info("✓ Doble clic completado exitosamente")
                                return True
                            else:
                                # Intentar invoke si no tiene coordenadas válidas
                                self.logger.info("Coordenadas inválidas, intentando invoke...")
                                try:
                                    descendant.invoke()
                                    time.sleep(1)
                                    self.logger.info("✓ Invocado correctamente")
                                    return True
                                except Exception:
                                    pyautogui.press('return')
                                    time.sleep(1)
                                    self.logger.info("✓ Enter presionado")
                                    return True
                    
                    except Exception:
                        pass
                
                self.logger.warning("'Trabar Intervención en Información' no encontrado en descendientes")
                return False
            
            except Exception as e:
                self.logger.error(f"Error iterando: {e}")
                return False
        
        except Exception as e:
            self.logger.error(f"Error en click_trabar_intervencion: {e}")
            return False
    
    def iei_enter_interventor(self, interventor: str) -> Outcome:
        """Ingresa código de INTERVENTOR. Retorna OK_RC si OK, SKIP_INTERVENTOR_INVALIDO si error."""
        try:
            self.logger.info(f"Ingresando INTERVENTOR: {interventor}")
            
            # Presionar ENTER primero (confirmación de diálogo anterior)
            pyautogui.press('return')
            time.sleep(1)
            
            # Buscar campo INTERVENTOR
            desktop = Desktop(backend=MSAA_BACKEND)
            interventor_field = None
            
            for element in self.iter_all_descendants():
                try:
                    name = str(element.element_info.name or "").lower()
                    if "interventor" in name and "Edit" in str(element.element_info.control_type):
                        interventor_field = element
                        break
                except Exception:
                    continue
            
            if not interventor_field:
                self.logger.error("No se encontró campo INTERVENTOR")
                return Outcome.FAIL_UI
            
            # Ingresar código
            interventor_field.set_focus()
            time.sleep(0.3)
            pyautogui.write(str(interventor), interval=0.05)
            time.sleep(0.5)
            pyautogui.press('return')
            time.sleep(1)
            
            int_err, int_msg = self.detect_interventor_error(timeout=2.0)
            if int_err:
                self.logger.warning(f"Error en interventor: {int_msg}")
                pyautogui.press('escape')
                time.sleep(0.5)
                return Outcome.SKIP_INTERVENTOR_INVALIDO
            
            self.logger.info(f"INTERVENTOR ingresado correctamente")
            return Outcome.OK_RC
        
        except Exception as e:
            self.logger.error(f"Error ingresando interventor: {e}")
            return Outcome.FAIL_UI
    
    def iei_set_plazo_and_confirm(self, plazo: int) -> Tuple[Outcome, Optional[str]]:
        """Ingresa PLAZO, presiona ALT+S y espera RC. Retorna (Outcome, rc_number)."""
        try:
            self.logger.info(f"Ingresando PLAZO: {plazo}")
            
            # Buscar campo PLAZO
            desktop = Desktop(backend=MSAA_BACKEND)
            plazo_field = None
            
            for element in self.iter_all_descendants():
                try:
                    name = str(element.element_info.name or "").lower()
                    if "plazo" in name and "Edit" in str(element.element_info.control_type):
                        plazo_field = element
                        break
                except Exception:
                    continue
            
            if not plazo_field:
                self.logger.error("No se encontró campo PLAZO")
                return (Outcome.FAIL_UI, None)
            
            # Ingresar plazo
            plazo_field.set_focus()
            time.sleep(0.3)
            pyautogui.write(str(plazo), interval=0.05)
            time.sleep(0.5)
            pyautogui.press('return')
            time.sleep(1)
            
            # Presionar ALT+S para grabar
            self.logger.info("Presionando ALT+S para grabar...")
            pyautogui.hotkey('alt', 's')
            time.sleep(2)
            
            # Esperar mensaje de RC
            rc_number = self._extract_rc_from_dialog()
            
            if rc_number:
                self.logger.info(f"RC extraída: {rc_number}")
                # Cerrar diálogo con ALT+A
                pyautogui.hotkey('alt', 'a')
                time.sleep(1)
                return (Outcome.OK_RC, rc_number)
            else:
                self.logger.warning("No se encontró confirmación de RC")
                return (Outcome.OK_RC, None)  # Por ahora OK aunque sin RC
        
        except Exception as e:
            self.logger.error(f"Error en iei_set_plazo_and_confirm: {e}")
            return (Outcome.FAIL_UI, None)
    
    # ========================================================================
    # ========================================================================
    # SELECCIÓN DE TIPO DE EMBARGO
    # ========================================================================
    
    def select_embargo_type(self, tipo_medida: str) -> bool:
        """
        Selecciona el tipo de embargo (IEI o DSE) en 'Trabar Embargo'.
        
        Args:
            tipo_medida: "IEI" o "DSE"
        
        Returns:
            True si se seleccionó correctamente, False si hubo error
        """
        try:
            tipo_upper = str(tipo_medida).strip().upper()
            
            if "IEI" in tipo_upper:
                self.logger.info("Seleccionando IEI (Intervención)...")
                return self.click_trabar_intervencion()
            elif "DSE" in tipo_upper:
                self.logger.info("Seleccionando DSE (Depósito)...")
                return self.click_trabar_deposito()
            else:
                self.logger.error(f"Tipo de medida no válido: {tipo_medida}")
                return False
        
        except Exception as e:
            self.logger.error(f"Error seleccionando tipo de embargo: {e}")
            return False
    
    # DSE (DEPÓSITO)
    # ========================================================================
    
    def click_trabar_deposito(self) -> bool:
        """Hace doble clic en 'Trabar Depósito sin Extracción' usando patrón robusto."""
        try:
            self.logger.info("Buscando 'Trabar Depósito sin Extracción'...")
            
            desktop = Desktop(backend=MSAA_BACKEND)
            
            # Buscar ventana SIRAT
            app = None
            try:
                app = desktop.window(title_re=".*SIRAT.*")
                if not app.exists(timeout=2):
                    app = None
            except Exception:
                app = None
            
            if not app:
                try:
                    app = desktop.active()
                except Exception:
                    app = None
            
            if not app:
                self.logger.error("No se encontró ventana SIRAT")
                return False
            
            self.logger.info("Ventana encontrada, iterando descendientes...")
            
            try:
                descendants = app.descendants()
                self.logger.info(f"Total de descendientes: {len(descendants)}")
                
                # Iterar todos los descendientes y buscar "Trabar Depósito sin Extracción"
                for i, descendant in enumerate(descendants):
                    try:
                        desc_text = descendant.window_text().strip()  # ← IMPORTANTE: strip()
                        
                        # Búsqueda exacta con strip()
                        if desc_text == "Trabar Depósito sin Extracción":
                            self.logger.info(f"✓ 'Trabar Depósito sin Extracción' encontrado en índice {i}")
                            rect = descendant.rectangle()
                            
                            if rect.width() > 0 and rect.height() > 0:
                                click_x = (rect.left + rect.right) // 2
                                click_y = (rect.top + rect.bottom) // 2
                                self.logger.info(f"Coordenadas válidas: ({click_x}, {click_y})")
                                self.logger.info(f"Haciendo DOBLE CLIC en: ({click_x}, {click_y})")
                                pyautogui.doubleClick(click_x, click_y)
                                time.sleep(1.5)
                                self.logger.info("✓ Doble clic completado exitosamente")
                                return True
                            else:
                                # Intentar invoke si no tiene coordenadas válidas
                                self.logger.info("Coordenadas inválidas, intentando invoke...")
                                try:
                                    descendant.invoke()
                                    time.sleep(1)
                                    self.logger.info("✓ Invocado correctamente")
                                    return True
                                except Exception:
                                    pyautogui.press('return')
                                    time.sleep(1)
                                    self.logger.info("✓ Enter presionado")
                                    return True
                    
                    except Exception:
                        pass
                
                self.logger.warning("'Trabar Depósito sin Extracción' no encontrado en descendientes")
                return False
            
            except Exception as e:
                self.logger.error(f"Error iterando: {e}")
                return False
        
        except Exception as e:
            self.logger.error(f"Error en click_trabar_deposito: {e}")
            return False
    
    def dse_set_monto_and_confirm(self, monto: float) -> Tuple[Outcome, Optional[str]]:
        """
        Ingresa MONTO en campo PBEDIT123 y maneja confirmaciones.
        
        Flujo DSE:
        1. Escribir monto
        2. Alt+A para validar
        3. Si monto > 20% saldo → Retorna SKIP_MONTO_MAYOR
        4. Loop secuencial de avisos:
           - Embargos activos (expediente + ruc + embargo + activo)
           - "¿ Desea Continuar ?" (con espacios) → Alt+S
           - Esperar mensaje "Se grabó la Resolución Coactiva con el número XXX"
           - Extraer RC (preservando 0s iniciales)
        5. Retorna (OK_RC, numero_rc_string)
        
        IMPORTANTE: RC se retorna como STRING para preserve 0s iniciales
        """
        try:
            self.logger.info(f"Ingresando MONTO: {monto}")
            
            # Presionar ENTER primero para cualquier aviso pendiente
            pyautogui.press('return')
            time.sleep(0.5)
            
            # Buscar campo PBEDIT123 específicamente
            desktop = Desktop(backend=MSAA_BACKEND)
            monto_field = None
            
            # Estrategia 1: Buscar PBEDIT123 exactamente
            self.logger.info("Buscando campo PBEDIT123 para MONTO...")
            for win in desktop.windows():
                try:
                    for element in win.descendants():
                        try:
                            class_name = str(element.element_info.class_name or "").strip()
                            if class_name == "PBEDIT123":
                                self.logger.info("✓ Campo PBEDIT123 encontrado")
                                monto_field = element
                                break
                        except Exception:
                            continue
                    if monto_field:
                        break
                except Exception:
                    continue
            
            # Estrategia 2: Fallback - buscar cualquier PBEDIT
            if not monto_field:
                self.logger.info("PBEDIT123 no encontrado, buscando cualquier PBEDIT...")
                monto_field = self._find_pbedit_field()
            
            if not monto_field:
                self.logger.error("No se encontró campo PBEDIT123 ni alternativo")
                return (Outcome.FAIL_UI, None)
            
            # Hacer clic en el campo para asegurar focus
            try:
                rect = monto_field.rectangle()
                if rect and rect.width() > 0 and rect.height() > 0:
                    click_x = (rect.left + rect.right) // 2
                    click_y = (rect.top + rect.bottom) // 2
                    pyautogui.click(click_x, click_y)
                    time.sleep(0.3)
            except Exception:
                pass
            
            # Establecer focus
            monto_field.set_focus()
            time.sleep(0.3)
            
            # Limpiar campo si tiene contenido
            try:
                pyautogui.hotkey('ctrl', 'a')
                time.sleep(0.1)
            except Exception:
                pass
            
            # Ingresar monto con conversión a string para preservar formato
            monto_str = str(monto).replace(',', '.')  # Asegurar punto decimal
            self.logger.info(f"Escribiendo monto: {monto_str}")
            pyautogui.write(monto_str, interval=0.05)
            time.sleep(0.5)
            
            # Presionar ALT+A para validar
            self.logger.info("Presionando ALT+A para validar monto...")
            pyautogui.hotkey('alt', 'a')
            time.sleep(2)
            
            # Verificar si aparece "monto mayor"
            monto_mayor_detected, monto_mayor_msg = self.detect_monto_aviso(timeout=2.0)
            if monto_mayor_detected:
                self.logger.warning(f"Monto mayor que saldo: {monto_mayor_msg}")
                # Presionar ENTER para confirmar y salir
                pyautogui.press('return')
                time.sleep(1)
                return (Outcome.SKIP_MONTO_MAYOR, None)
            
            # Manejar avisos en secuencia (pueden ser variables según el caso)
            # Loop hasta que se encuentre el RC o se agoten los reintentos
            max_avisos = 10  # Protección contra loops infinitos
            avisos_procesados = 0
            rc_number = None
            
            self.logger.info("Iniciando detección secuencial de avisos...")
            while avisos_procesados < max_avisos:
                avisos_procesados += 1
                
                # 1. Aviso de embargos activos (puede aparecer nuevamente)
                embargo_detected, embargo_msg = self.detect_expediente_aviso(timeout=0.5)
                if embargo_detected:
                    self.logger.info(f"[{avisos_procesados}] Detectado aviso de embargos activos: {embargo_msg}")
                    pyautogui.hotkey('alt', 's')
                    time.sleep(1)
                    continue
                
                # 2. "¿ Desea Continuar ?" (CON ESPACIOS - muy importante)
                desea_detected, desea_msg = self.detect_desea_continuar_aviso(timeout=0.5)
                if desea_detected:
                    self.logger.info(f"[{avisos_procesados}] Detectado '¿ Desea Continuar ?': {desea_msg}")
                    pyautogui.hotkey('alt', 's')
                    time.sleep(1)
                    
                    # DESPUÉS de responder "¿ Desea Continuar ?", aparece el mensaje del RC
                    # Esperar a que aparezca: "Se grabó la Resolución Coactiva con el número XXX"
                    self.logger.info("Esperando mensaje de RC después de '¿ Desea Continuar ?'...")
                    rc_detected, rc_number = self.detect_rc_message(timeout=3)
                    
                    if rc_detected and rc_number:
                        self.logger.info(f"✓ RC extraída correctamente: {rc_number}")
                        # Presionar ENTER para cerrar el diálogo del mensaje RC
                        self.logger.info("Presionando ENTER para confirmar/cerrar diálogo RC...")
                        pyautogui.press('return')
                        time.sleep(1)
                        # Presionar ALT+C para cerrar la ventana actual
                        self.logger.info("Presionando ALT+C para cerrar ventana...")
                        pyautogui.hotkey('alt', 'c')
                        time.sleep(1)
                        return (Outcome.OK_RC, rc_number)
                    else:
                        self.logger.warning("No se detectó el mensaje de RC después de '¿ Desea Continuar ?'")
                        # Aunque no hayamos detectado el RC, continuar
                        return (Outcome.OK_RC, None)
                
                # Si no se detectó ningún aviso, salir del loop
                self.logger.info("No se detectaron más avisos")
                break
            
            # Si llegamos aquí, el monto fue aceptado pero sin avisos adicionales
            self.logger.warning("Monto procesado sin avisos adicionales (puede ser válido)")
            return (Outcome.OK_RC, None)
        
        except Exception as e:
            self.logger.error(f"Error en dse_set_monto_and_confirm: {e}")
            return (Outcome.FAIL_UI, None)
    
    # ========================================================================
    # REINICIO DE FLUJO PARA SIGUIENTE EXPEDIENTE
    # ========================================================================
    
    def click_proceso_embargo_for_restart(self) -> bool:
        """
        Hace clic en "Proceso de Embargo" desde el menú principal.
        Se usa como primer paso en el reinicio de flujo.
        """
        try:
            self.logger.info("  [1/3] Haciendo clic en 'Proceso de Embargo'...")
            
            desktop = Desktop(backend=MSAA_BACKEND)
            app = None
            try:
                app = desktop.window(title_re=".*SIRAT.*")
                if not app.exists(timeout=2):
                    app = None
            except:
                app = None
            
            if not app:
                try:
                    app = desktop.active()
                except:
                    return False
            
            if not app:
                return False
            
            # Buscar "Proceso de Embargo"
            try:
                descendants = app.descendants()
                for descendant in descendants:
                    try:
                        desc_text = descendant.window_text().strip()
                        if desc_text == "Proceso de Embargo":
                            rect = descendant.rectangle()
                            if rect and rect.width() > 0 and rect.height() > 0:
                                click_x = (rect.left + rect.right) // 2
                                click_y = (rect.top + rect.bottom) // 2
                                pyautogui.click(click_x, click_y)
                                time.sleep(1)
                                return True
                    except:
                        pass
            except:
                pass
            
            return False
        except Exception as e:
            self.logger.warning(f"Error en click_proceso_embargo_for_restart: {e}")
            return False
    
    def click_accesos_from_menu(self) -> bool:
        """
        Hace clic en "Accesos" después de expandir "Proceso de Embargo".
        Se usa como segundo paso en el reinicio de flujo.
        """
        try:
            self.logger.info("  [2/3] Haciendo clic en 'Accesos'...")
            
            desktop = Desktop(backend=MSAA_BACKEND)
            app = None
            try:
                app = desktop.window(title_re=".*SIRAT.*")
                if not app.exists(timeout=2):
                    app = None
            except:
                app = None
            
            if not app:
                try:
                    app = desktop.active()
                except:
                    return False
            
            if not app:
                return False
            
            # Buscar "Accesos"
            try:
                descendants = app.descendants()
                for descendant in descendants:
                    try:
                        desc_text = descendant.window_text().strip()
                        if desc_text == "Accesos":
                            rect = descendant.rectangle()
                            if rect and rect.width() > 0 and rect.height() > 0:
                                click_x = (rect.left + rect.right) // 2
                                click_y = (rect.top + rect.bottom) // 2
                                pyautogui.click(click_x, click_y)
                                time.sleep(1)
                                return True
                    except:
                        pass
            except:
                pass
            
            return False
        except Exception as e:
            self.logger.warning(f"Error en click_accesos_from_menu: {e}")
            return False
    
    def double_click_cambio_expediente(self) -> bool:
        """
        Hace DOBLE clic en "Cambio de Expediente" después de seleccionar "Accesos".
        Se usa como tercer paso en el reinicio de flujo.
        Esto prepara para ingresar el siguiente expediente.
        """
        try:
            self.logger.info("  [3/3] Haciendo doble clic en 'Cambio de Expediente'...")
            
            desktop = Desktop(backend=MSAA_BACKEND)
            app = None
            try:
                app = desktop.window(title_re=".*SIRAT.*")
                if not app.exists(timeout=2):
                    app = None
            except:
                app = None
            
            if not app:
                try:
                    app = desktop.active()
                except:
                    return False
            
            if not app:
                return False
            
            # Buscar "Cambio de Expediente"
            try:
                descendants = app.descendants()
                for descendant in descendants:
                    try:
                        desc_text = descendant.window_text().strip()
                        if desc_text == "Cambio de Expediente":
                            rect = descendant.rectangle()
                            if rect and rect.width() > 0 and rect.height() > 0:
                                click_x = (rect.left + rect.right) // 2
                                click_y = (rect.top + rect.bottom) // 2
                                self.logger.info(f"    Coordenadas: ({click_x}, {click_y})")
                                # Doble clic
                                pyautogui.doubleClick(click_x, click_y)
                                time.sleep(1.5)
                                return True
                    except:
                        pass
            except:
                pass
            
            return False
        except Exception as e:
            self.logger.warning(f"Error en double_click_cambio_expediente: {e}")
            return False
    
    def restart_embargo_flow(self) -> bool:
        """
        Reinicia el flujo de embargo para pasar al siguiente expediente.
        
        Secuencia:
        1. Click en "Proceso de Embargo"
        2. Click en "Accesos"
        3. Doble clic en "Cambio de Expediente"
        
        Se usa después de completar un expediente DSE (cuando ya se extrajo RC).
        
        Retorna: True si completó todos los pasos, False si hay error
        """
        try:
            self.logger.info("\n[REINICIO] Reiniciando flujo para siguiente expediente...")
            
            if not self.click_proceso_embargo_for_restart():
                self.logger.warning("  ✗ No se pudo hacer clic en 'Proceso de Embargo'")
                return False
            
            if not self.click_accesos_from_menu():
                self.logger.warning("  ✗ No se pudo hacer clic en 'Accesos'")
                return False
            
            if not self.double_click_cambio_expediente():
                self.logger.warning("  ✗ No se pudo hacer doble clic en 'Cambio de Expediente'")
                return False
            
            self.logger.info("  ✓ Flujo reiniciado exitosamente")
            return True
        
        except Exception as e:
            self.logger.error(f"Error reiniciando flujo de embargo: {e}")
            return False
    
    # ========================================================================
    # EXTRACCIÓN DE RC
    # ========================================================================
    
    def _extract_rc_from_dialog(self) -> Optional[str]:
        """Busca mensaje de RC y extrae el número. Retorna string "XXXXX" o None."""
        try:
            desktop = Desktop(backend=MSAA_BACKEND)
            
            for element in self.iter_all_descendants():
                try:
                    text = str(element.element_info.name or "").lower()
                    
                    if "se grabó" in text and "resolución" in text and "número" in text:
                        # Encontrado el mensaje, extraer número
                        full_text = str(element.element_info.name or "")
                        
                        # Buscar la palabra "número" y extraer dígitos después
                        idx = full_text.lower().find("número")
                        if idx >= 0:
                            after_numero = full_text[idx + 6:]
                            # Extraer dígitos consecutivos
                            rc = ""
                            for char in after_numero:
                                if char.isdigit():
                                    rc += char
                                elif rc:  # Si ya tenemos dígitos y encontramos no-dígito, terminar
                                    break
                            
                            if rc:
                                return rc
                except Exception:
                    continue
            
            return None
        
        except Exception as e:
            self.logger.warning(f"Error extrayendo RC: {e}")
            return None
