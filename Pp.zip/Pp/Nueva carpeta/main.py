"""
main.py - Orquestación principal de la automatización RSIRAT
Responsabilidades:
  1. Cargar Excel (EXPEDIENTES.xlsx)
  2. Agrupar expedientes por DEPENDENCIA
  3. Determinar orden (mayor cantidad primero)
  4. Inicializar logger y AppDriver
  5. Llamar workflow.process_dependency por cada dependencia
  6. Guardar resultados en R_EXPEDIENTES.xlsx
  7. Finalizar limpiamente
"""

import logging
import sys
from pathlib import Path
from datetime import datetime
import pandas as pd
from openpyxl import load_workbook
import unicodedata

from app_driver import AppDriver
from workflow import process_dependency, Outcome


# ============================================================================
# CONSTANTES
# ============================================================================
SCRIPT_DIR = Path(__file__).parent if getattr(sys, 'frozen', False) == False else Path(sys.executable).parent
EXCEL_INPUT = SCRIPT_DIR / "EXPEDIENTES.xlsx"
EXCEL_OUTPUT = SCRIPT_DIR / "R_EXPEDIENTES.xlsx"
LOG_FILE = SCRIPT_DIR / "proceso_log32.txt"
PASSWORD_FILE = SCRIPT_DIR / "contrasena.txt"
SHORTCUT_PATH = SCRIPT_DIR / "Actualiza RSIRAT.lnk"


# ============================================================================
# UTILIDADES LOGGER
# ============================================================================
def _remove_accents(text: str) -> str:
    """Remueve tildes/diacríticos para evitar caracteres mal codificados."""
    if not isinstance(text, str):
        return text
    return ''.join(c for c in unicodedata.normalize('NFD', text) if unicodedata.category(c) != 'Mn')


class AsciiFormatter(logging.Formatter):
    """Formatter que limpia diacríticos en mensajes."""
    def format(self, record):
        try:
            if isinstance(record.msg, str):
                record.msg = _remove_accents(record.msg)
            if record.args:
                record.args = tuple(_remove_accents(str(a)) if isinstance(a, str) else a for a in record.args)
        except Exception:
            pass
        return super().format(record)


def setup_logger():
    """Configura logger con archivo y consola."""
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    
    # File handler
    file_handler = logging.FileHandler(LOG_FILE, encoding='utf-8')
    file_handler.setLevel(logging.INFO)
    
    # Stream handler (consola)
    stream_handler = logging.StreamHandler()
    stream_handler.setLevel(logging.INFO)
    
    # Formatter
    fmt = '%(asctime)s - %(levelname)s - %(message)s'
    formatter = AsciiFormatter(fmt)
    file_handler.setFormatter(formatter)
    stream_handler.setFormatter(formatter)
    
    logger.addHandler(file_handler)
    logger.addHandler(stream_handler)
    
    return logger


# ============================================================================
# CARGA Y VALIDACIÓN EXCEL
# ============================================================================
def load_excel_expedientes():
    """Carga EXPEDIENTES.xlsx y retorna DataFrame."""
    if not EXCEL_INPUT.exists():
        raise FileNotFoundError(f"No existe {EXCEL_INPUT}")
    
    # Leer la columna EXPEDIENTE como texto para preservar ceros iniciales
    try:
        df = pd.read_excel(EXCEL_INPUT, dtype={"EXPEDIENTE": str}, keep_default_na=False)
    except Exception:
        # Fallback genérico
        df = pd.read_excel(EXCEL_INPUT)
    
    # Validar columnas obligatorias
    required_cols = ["DEPENDENCIA", "TIPO DE MEDIDA", "INTERVENTOR", "PLAZO", "MONTO", "EXPEDIENTE"]
    missing = [c for c in required_cols if c not in df.columns]
    if missing:
        raise ValueError(f"Faltan columnas: {missing}")
    
    return df


def load_password():
    """Carga contraseña desde contrasena.txt."""
    if not PASSWORD_FILE.exists():
        raise FileNotFoundError(f"No existe {PASSWORD_FILE}")
    
    with open(PASSWORD_FILE, "r", encoding="utf-8") as f:
        return f.read().strip()


def group_by_dependencia(df):
    """
    Agrupa expedientes por DEPENDENCIA.
    Retorna dict: {"21": [indices], "23": [indices]}
    Orden: dependencia con más expedientes primero.
    """
    dep_21 = df[df["DEPENDENCIA"].astype(str).str.strip() == "21"].index.tolist()
    dep_23 = df[df["DEPENDENCIA"].astype(str).str.strip() == "23"].index.tolist()
    
    result = {}
    if dep_21:
        result["21"] = dep_21
    if dep_23:
        result["23"] = dep_23
    
    # Ordenar por cantidad (descendente): mayor cantidad primero
    sorted_deps = sorted(result.keys(), key=lambda d: len(result[d]), reverse=True)
    
    return {d: result[d] for d in sorted_deps}


# ============================================================================
# ACTUALIZACIÓN RESULTADOS EXCEL
# ============================================================================
def ensure_r_expedientes_exists(df_original):
    """Si R_EXPEDIENTES.xlsx no existe, lo crea como copia de EXPEDIENTES.xlsx."""
    if not EXCEL_OUTPUT.exists():
        df_original.to_excel(EXCEL_OUTPUT, index=False, engine='openpyxl')
        try:
            wb = load_workbook(EXCEL_OUTPUT)
            ws = wb.active
            for row in ws.iter_rows():
                for cell in row:
                    try:
                        cell.number_format = '@'
                    except Exception:
                        pass
            wb.save(EXCEL_OUTPUT)
        except Exception:
            pass


def update_result_in_excel(row_idx, outcome_str, rc_number=None):
    """
    Actualiza la columna RESULTADO en R_EXPEDIENTES.xlsx.
    
    Args:
        row_idx: índice 0-based de la fila (será row_idx + 2 en Excel)
        outcome_str: descripción del resultado (ej: "OK_RC", "EXP_INVALIDO", etc.)
        rc_number: número de RC si aplica (se guarda como STRING para preservar 0s)
    """
    try:
        logger = logging.getLogger(__name__)
        wb = load_workbook(EXCEL_OUTPUT)
        ws = wb.active
        
        # Crear columa RESULTADO si no existe
        headers = {cell.value: idx for idx, cell in enumerate(ws[1], 1) if cell.value}
        if "RESULTADO" not in headers:
            resultado_col = len(headers) + 1
            ws.cell(row=1, column=resultado_col, value="RESULTADO")
        else:
            resultado_col = headers["RESULTADO"]
        
        # Escribir resultado
        target_row = row_idx + 2  # +1 header, +1 0-based
        
        if rc_number:
            # Si tenemos RC, guardarlo como TEXTO (string) para preservar 0s iniciales
            # Ejemplo: "00123456" no "123456"
            result_value = str(rc_number)
            cell = ws.cell(row=target_row, column=resultado_col, value=result_value)
            
            # Forzar formato texto en la celda (openpyxl)
            # data_type='s' indica que es un STRING en openpyxl
            cell.data_type = 's'
            
            # También aplicar formato de celda como texto
            cell.number_format = '@'
            
            logger.info(f"  RC guardada como TEXTO en Excel (fila {target_row}): '{result_value}'")
        else:
            # Si no hay RC, guardar el mensaje de outcome
            result_value = outcome_str
            cell = ws.cell(row=target_row, column=resultado_col, value=result_value)
            logger.info(f"  Resultado guardado en Excel (fila {target_row}): '{result_value}'")
        
        wb.save(EXCEL_OUTPUT)
    except Exception as e:
        logger = logging.getLogger(__name__)
        logger.error(f"Error actualizando Excel fila {row_idx + 1}: {e}")


def update_ejecutor_correcto_in_excel(row_idx, value: str):
    """
    Actualiza (o crea) la columna EJECUTOR_CORRECTO en R_EXPEDIENTES.xlsx.
    value: 'SI' o 'NO' u otra marca.
    """
    try:
        wb = load_workbook(EXCEL_OUTPUT)
        ws = wb.active

        headers = {cell.value: idx for idx, cell in enumerate(ws[1], 1) if cell.value}
        if "EJECUTOR_CORRECTO" not in headers:
            col = len(headers) + 1
            ws.cell(row=1, column=col, value="EJECUTOR_CORRECTO")
            headers["EJECUTOR_CORRECTO"] = col

        target_row = row_idx + 2
        col_idx = headers["EJECUTOR_CORRECTO"]
        cell = ws.cell(row=target_row, column=col_idx, value=value)
        try:
            cell.number_format = '@'
        except Exception:
            pass
        wb.save(EXCEL_OUTPUT)
    except Exception as e:
        logger = logging.getLogger(__name__)
        logger.error(f"Error actualizando EJECUTOR_CORRECTO fila {row_idx + 1}: {e}")


# ============================================================================
# MAIN
# ============================================================================
def main():
    """Orquestación principal."""
    logger = setup_logger()
    
    logger.info("=" * 70)
    logger.info("INICIANDO AUTOMATIZACIÓN RSIRAT (32-bit)")
    logger.info("=" * 70)
    logger.info(f"Directorio de trabajo: {SCRIPT_DIR}")
    logger.info(f"Excel entrada: {EXCEL_INPUT}")
    logger.info(f"Excel salida: {EXCEL_OUTPUT}")
    
    try:
        # -------- Cargar datos --------
        logger.info("\n[FASE 1] Cargando datos...")
        df_expedientes = load_excel_expedientes()
        password = load_password()
        logger.info(f"   Cargados {len(df_expedientes)} expedientes")
        
        # -------- Agrupar por dependencia --------
        logger.info("\n[FASE 2] Agrupando por DEPENDENCIA...")
        deps_items = group_by_dependencia(df_expedientes)
        
        if not deps_items:
            logger.error("No hay expedientes válidos (DEPENDENCIA vacía)")
            return False
        
        logger.info(f"   {len(deps_items)} dependencia(s) encontrada(s)")
        for dep, indices in deps_items.items():
            logger.info(f"    - Dependencia {dep}: {len(indices)} expediente(s)")
        
        # -------- Crear archivo de salida --------
        logger.info("\n[FASE 3] Preparando archivo de resultados...")
        ensure_r_expedientes_exists(df_expedientes)
        logger.info(f"   {EXCEL_OUTPUT} preparado")
        
        # -------- Inicializar AppDriver --------
        logger.info("\n[FASE 4] Inicializando controlador de aplicación...")
        driver = AppDriver(logger, SHORTCUT_PATH)
        
        # -------- Procesar cada dependencia --------
        all_outcomes = []
        for dep_order, (dependencia, indices) in enumerate(deps_items.items(), 1):
            logger.info("\n" + "=" * 70)
            logger.info(f"[DEPENDENCIA {dep_order}/{len(deps_items)}] Procesando DEP={dependencia}")
            logger.info("=" * 70)
            
            # Siempre abrir la app para cada dependencia (se cierra entre dependencias)
            is_first = True
            is_last = (dep_order == len(deps_items))
            
            # Procesar dependencia
            outcomes = process_dependency(
                dependencia=dependencia,
                indices=indices,
                df=df_expedientes,
                driver=driver,
                update_result_fn=update_result_in_excel,
                update_ejecutor_fn=update_ejecutor_correcto_in_excel,
                is_first=is_first,
                is_last=is_last,
                logger=logger,
                password=password
            )
            
            all_outcomes.extend(outcomes)
            
            # Si hubo FAIL_LOGIN_PASSWORD, detener todo
            if any(o.outcome == Outcome.FAIL_LOGIN_PASSWORD for o in outcomes):
                logger.error("\n[CRÍTICO] Login falló con contraseña incorrecta. Abortando ejecución.")
                break
            
            # Si no es la última, cerrar app (Alt+F4) antes de siguiente dependencia
            if not is_last:
                logger.info("\nCerrando aplicación para cambiar de dependencia...")
                driver.close_app()
        
        # -------- Resumen final --------
        logger.info("\n" + "=" * 70)
        logger.info("RESUMEN FINAL")
        logger.info("=" * 70)
        
        success_count = sum(1 for o in all_outcomes if o.outcome == Outcome.OK_RC)
        skip_count = sum(1 for o in all_outcomes if "SKIP" in o.outcome.name)
        fail_count = sum(1 for o in all_outcomes if "FAIL" in o.outcome.name)
        
        logger.info(f"  Éxito (RC grabada):     {success_count}")
        logger.info(f"  Saltos (inválidos):     {skip_count}")
        logger.info(f"  Fallos (UI/config):     {fail_count}")
        logger.info(f"  TOTAL:                  {len(all_outcomes)}")
        
        logger.info("\n Proceso completado")
        return True
    
    except Exception as e:
        logger.error(f"\n[CRÍTICO] Error no controlado: {e}", exc_info=True)
        return False
    
    finally:
        logger.info("=" * 70)


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
